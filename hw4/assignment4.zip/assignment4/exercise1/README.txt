jzhan127 jason zhang
running exercise 1
-put source_routing in p4_src
-put commands in the directory outside
-run run_demo
-inside mininet run xterm h1 h3
-on h1 run python send.py h1 h3
-on h3 run python receive.py
-you should now see messages go through