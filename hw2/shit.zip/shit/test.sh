h4 python start_server.py 4
h1 ./miProxy log1 0.5 4000 10.0.0.4 & python launch_firefox.py 1
h2 ./miProxy log2 0.5 4001 10.0.0.4 & python launch_firefox.py 1
h3 ./miProxy log3 1.0 4002 10.0.0.4 & python launch_firefox.py 1